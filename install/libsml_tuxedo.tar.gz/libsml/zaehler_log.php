<?php

$output = shell_exec("/opt/libsml/examples/sml_server /dev/ttyUSB1");
echo $output."\n";
$lines = explode("\n", $output);
$wirkleistung_og = explode(" ",$lines[0])[1];
$wirkleistung_aktuell_og = explode(" ",$lines[3])[1];
echo "OG wirkleistung: ".$wirkleistung_og." Wh\n";
echo "OG wirkleistung aktuell: ".$wirkleistung_aktuell_og." W\n";

$output = shell_exec("/opt/libsml/examples/sml_server /dev/ttyUSB0");
$lines = explode("\n", $output);
$wirkleistung_eg = explode(" ",$lines[0])[1];
$wirkleistung_aktuell_eg = explode(" ",$lines[3])[1];
echo "EG wirkleistung: ".$wirkleistung_eg." Wh\n";
echo "EG wirkleistung aktuell: ".$wirkleistung_aktuell_eg." W\n";


#$result = file_get_contents("http://192.168.0.133/zaehler/controller.php?operation=addArray&ids=61|62|63|64&values=".$wirkleistung_og."|".$wirkleistung_aktuell_og."|".$wirkleistung_eg."|".$wirkleistung_aktuell_eg);
#echo $result."\n"; 
?>
