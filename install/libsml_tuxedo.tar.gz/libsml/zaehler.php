<?php
echo "-----------------\n";
$date = time();
echo date("r")." time=".$date."\n";
$output = shell_exec("/opt/libsml/examples/sml_server /dev/ttyUSB0");
$lines = explode("\n", $output);

echo print_r($lines, true)."\n";

$line0 = explode(" ", $lines[0]);
$line2 = explode(" ", $lines[2]);
$line4 = explode(" ", $lines[4]);

$zaehler_bezug                = $line0[1];
$zaehler_eingespeist          = $line2[1];
$zaehler_wirkleistung_aktuell = $line4[1];

echo "Bezug: ".$zaehler_bezug." Wh\n";
echo "Eingespeist: ".$zaehler_eingespeist." Wh\n";
echo "Wirkleistung aktuell: ".$zaehler_wirkleistung_aktuell." W\n";


echo date("r")."\n";

$url = "http://192.168.0.133/zaehler/controller.php?DEBUG_ID=zaehler_UG_".$date."&operation=addArray&ids=65|66|67&values=".$zaehler_bezug."|".$zaehler_eingespeist."|".$zaehler_wirkleistung_aktuell;
echo "url={".$url."}\n";
$result = file_get_contents($url);
echo "result: {".$result."}\n"; 
echo date("r")."\n";

?>
