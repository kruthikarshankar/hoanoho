#!/bin/bash
while [[ true ]] 
do
./examples/sml_server /dev/ttyUSB0 && ./examples/sml_server /dev/ttyUSB1
echo "-----------------"
done